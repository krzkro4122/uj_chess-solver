package edu.uj.po.interfaces;

/**
 * Kolor bierki.
 *
 */
public enum Color {
	BLACK, WHITE;
}
