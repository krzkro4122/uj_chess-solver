package edu.uj.po.interfaces;

/**
 * Wiersz na szachownicy
 */
public enum Rank {
	FIRST, SECOND, THIRD, FOURTH, FIFTH, SIXTH, SEVENTH, EIGHTH;
}
